import React, {Component} from 'react';

class A5 extends Component {

    componentDidMount () {
        ;
      }

      
  render() {
    return (
    <div class="card">
        {/* <div class="card-header card-header-warning">
            <h4 class="card-title">Emergency Contacts</h4>
        </div> */}
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead class="text-warning">
                    <th>A5</th>
                    {/* <th>Phone</th>
                    <th>Email</th> */}
                </thead>
                <tbody>
                    <tr>
                    </tr>                              
                </tbody>
            </table>
        </div>
    </div>
    )
  }
}

export default A5