import React, {Component} from 'react';
import SummaryService from '../../services/SummaryService'
import Summarybyline from './summarybyline'

class A3 extends Component {

    constructor(props){
        super(props);
        this.state = {
            error: null,
           
            summarys: []
        }
    }

    componentDidMount () {
        let userid = "base";
        SummaryService.loadTimesheet(userid)
            .then( response => {
                console.log(response);

                this.setState({
                    summarys:response.data,
                })
            })
    }






  render() {
    return (
    <div class="card">
        {/* <div class="card-header card-header-warning">
            <h4 class="card-title">Emergency Contacts</h4>
        </div> */}
        <div class="card-body table-responsive">
            <table class="table table-hover">
                {/* <thead class="text-warning">
                    <th>A3</th>
                    
                </thead>
                <tbody>
                    <tr>
                    </tr>                              
                </tbody> */}
                {
                    this.state.summarys.map((summarybyline)=>{
                        return (<Summarybyline>{summarybyline}</Summarybyline>)
                    })
                }
            </table>
        </div>
    </div>
    )
  }
}

export default A3