import React, {Component} from 'react';

const summarybyline = (props) => {
    return(
         <thead class="text-warning">
             <th>1111111111</th>
            <th>{props.weekending}</th>
            <th>{props.totalhours}</th>
            <th>{props.submission}</th>
            <th>{props.approval}</th>
            <th>{props.option}</th>
            <th>{props.comment}</th>
        </thead>
    )
}

export default summarybyline;